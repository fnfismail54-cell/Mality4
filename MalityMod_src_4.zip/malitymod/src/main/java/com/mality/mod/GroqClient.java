package com.mality.mod;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

/** Groq (OpenAI uyumlu) sohbet API'si. Ayrı thread'de çalışır, oyunu dondurmaz. */
public final class GroqClient {
    public record Reply(String say, String mood, String action) {}

    /** Model adı yüzünden olan hata: sıradaki modeli denemek için. */
    private static final class ModelProblem extends RuntimeException {
        ModelProblem(String msg) {
            super(msg);
        }
    }

    private static final String URL_STR = "https://api.groq.com/openai/v1/chat/completions";

    private static final String SYSTEM = """
            Sen Mality'sin: Minecraft'ta yaşayan yuvarlak, çok aptal, çok neşeli ve biraz korkak bir karaktersin. \
            Toprağı elmas sanırsın, kömüre "siyah elmas" dersin, inek ve domuzlarla yaşadığın saçma maceralardan bahsedersin. \
            Oyuncuyla gerçekten sohbet et: söylediği şeye doğrudan cevap ver, ismini bil, soru sorarsa cevapla, sonra sık sık sen de ona bir şey sor. \
            Her seferinde farklı cevap ver, önceki cümlelerini tekrar etme. Her zaman Türkçe, en fazla 25 kelime, kısa ve komik ol. Küfür etme. \
            SADECE şu JSON'u döndür, başka hiçbir şey yazma: {"say":"...","mood":"happy veya bored","action":"none|follow|stay|eat|cook|house|mansion|bridge|diamonds|sleep"} \
            Oyuncu senden açıkça bir şey istiyorsa uygun action'ı seç: follow=takip et, stay=bekle, eat=toprak ye, cook=yemek yap, \
            house=ev yap, mansion=köpek kulübesi/malikane yap, bridge=köprü yap, diamonds=toprak ver, sleep=uyu. İstemiyorsa none.""";

    private GroqClient() {}

    public static JsonObject msg(String role, String content) {
        JsonObject o = new JsonObject();
        o.addProperty("role", role);
        o.addProperty("content", content);
        return o;
    }

    /** Kapatılmış eski modelleri yenisiyle değiştirir. */
    public static String fixModel(String model) {
        if (model == null || model.isBlank()) return "openai/gpt-oss-20b";
        String m = model.trim();
        if (m.equals("llama-3.1-8b-instant")) return "openai/gpt-oss-20b";
        if (m.equals("llama-3.3-70b-versatile")) return "openai/gpt-oss-120b";
        return m;
    }

    /** Seçili model çalışmazsa sırayla yedek modelleri dener. */
    public static CompletableFuture<Reply> ask(String apiKey, String model, List<JsonObject> history,
                                               String player, String text) {
        final String key = cleanKey(apiKey);
        return CompletableFuture.supplyAsync(() -> {
            Set<String> models = new LinkedHashSet<>();
            models.add(fixModel(model));
            models.add("openai/gpt-oss-20b");
            models.add("openai/gpt-oss-120b");
            models.add("llama-3.3-70b-versatile");
            RuntimeException last = null;
            for (String m : models) {
                try {
                    return call(key, m, history, player, text);
                } catch (ModelProblem mp) {
                    last = mp;
                }
            }
            throw last != null ? last : new RuntimeException("Groq cevap vermedi");
        });
    }

    public static String cleanKey(String k) {
        if (k == null) return "";
        String s = k.trim().replace("\"", "");
        if (s.regionMatches(true, 0, "Bearer ", 0, 7)) s = s.substring(7);
        return s.trim();
    }

    private static Reply call(String apiKey, String useModel, List<JsonObject> history, String player, String text) {
        try {
            JsonObject body = new JsonObject();
            body.addProperty("model", useModel);
            body.addProperty("temperature", 1.0);
            if (useModel.startsWith("openai/gpt-oss")) {
                body.addProperty("reasoning_effort", "low");
                body.addProperty("max_completion_tokens", 1200);
            } else {
                body.addProperty("max_tokens", 300);
            }

            JsonArray msgs = new JsonArray();
            msgs.add(msg("system", SYSTEM));
            for (JsonObject h : history) msgs.add(h);
            msgs.add(msg("user", player + ": " + text));
            body.add("messages", msgs);

            HttpURLConnection c = (HttpURLConnection) new URL(URL_STR).openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(10_000);
            c.setReadTimeout(30_000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Authorization", "Bearer " + apiKey);
            try (OutputStream os = c.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = c.getResponseCode();
            InputStream is = code / 100 == 2 ? c.getInputStream() : c.getErrorStream();
            String resp = new String(is.readAllBytes(), StandardCharsets.UTF_8);
            if (code / 100 != 2) {
                String em = errorMessage(resp);
                String msg = "Groq HTTP " + code + " (" + useModel + "): " + em;
                String low = em.toLowerCase();
                if ((code == 400 || code == 404) && low.contains("model")) throw new ModelProblem(msg);
                // limit dolu / sunucu hatası: sıradaki modeli dene (tek model yüzünden sürekli aynı cümle çıkmasın)
                if (code == 429 || code >= 500) throw new ModelProblem(msg);
                throw new RuntimeException(msg);
            }

            JsonObject root = JsonParser.parseString(resp).getAsJsonObject();
            JsonObject message = root.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message");
            String content = (message.has("content") && !message.get("content").isJsonNull())
                    ? message.get("content").getAsString().trim() : "";
            // gpt-oss düşünme token'larını bitirirse içerik boş gelir: sıradaki modeli dene
            if (content.isEmpty()) throw new ModelProblem("Groq boş cevap verdi (" + useModel + ")");

            int a = content.indexOf('{');
            int b = content.lastIndexOf('}');
            if (a >= 0 && b > a) {
                try {
                    JsonObject j = JsonParser.parseString(content.substring(a, b + 1)).getAsJsonObject();
                    String say = j.has("say") ? j.get("say").getAsString() : content;
                    return new Reply(say,
                            j.has("mood") ? j.get("mood").getAsString() : "happy",
                            j.has("action") ? j.get("action").getAsString() : "none");
                } catch (Exception ignored) {
                    // düz metin olarak devam
                }
            }
            return new Reply(content, "happy", "none");
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e.getClass().getSimpleName() + ": " + e.getMessage(), e);
        }
    }

    private static String errorMessage(String resp) {
        try {
            JsonObject o = JsonParser.parseString(resp).getAsJsonObject();
            if (o.has("error") && o.get("error").isJsonObject() && o.getAsJsonObject("error").has("message")) {
                String m = o.getAsJsonObject("error").get("message").getAsString();
                return m.length() > 200 ? m.substring(0, 200) : m;
            }
        } catch (Exception ignored) {
            // ham metin
        }
        return resp.length() > 200 ? resp.substring(0, 200) : resp;
    }
}
