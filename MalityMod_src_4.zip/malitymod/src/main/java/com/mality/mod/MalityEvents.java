package com.mality.mod;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Comparator;
import java.util.List;

public class MalityEvents {

    /** /setmalityyatak : en yakın Mality'nin yatağını bulunduğun yere ayarlar. */
    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();
        d.register(Commands.literal("setmalityyatak").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            List<MalityEntity> list = p.serverLevel().getEntitiesOfClass(MalityEntity.class,
                    p.getBoundingBox().inflate(64.0D));
            if (list.isEmpty()) {
                ctx.getSource().sendFailure(Component.literal("Yakında Mality yok!"));
                return 0;
            }
            MalityEntity m = list.stream().min(Comparator.comparingDouble(e -> e.distanceToSqr(p))).get();
            m.setBed(p.blockPosition());
            ctx.getSource().sendSuccess(() -> Component.literal("\u00A7dMality'nin yatağı buraya ayarlandı!"), false);
            return 1;
        }));
    }

    /** /malitytest : Groq + Fish Audio + ses çalma testi. */
    @SubscribeEvent
    public void onTestCommand(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("malitytest").executes(ctx -> {
            MalityTest.run(ctx.getSource().getPlayerOrException());
            return 1;
        }));
    }

    /** Sohbet mesajlarını yakındaki Mality'ye ilet. */
    @SubscribeEvent
    public void onChat(ServerChatEvent event) {
        ServerPlayer p = event.getPlayer();
        String raw = event.getRawText();
        String folded = MalityEntity.fold(raw);
        if (Config.REQUIRE_MALITY.get() && !folded.contains("mality")) return;

        p.getServer().execute(() -> {
            List<MalityEntity> list = p.serverLevel().getEntitiesOfClass(MalityEntity.class,
                    p.getBoundingBox().inflate(Config.CHAT_RANGE.get()));
            list.stream().min(Comparator.comparingDouble(m -> m.distanceToSqr(p)))
                    .ifPresent(m -> m.hear(p, raw, folded));
        });
    }

    /** Minnoş (sahiplenilen zombi) kimseye saldırmaz. */
    @SubscribeEvent
    public void onTarget(LivingChangeTargetEvent event) {
        if (event.getEntity() instanceof Zombie z && z.getPersistentData().getBoolean(MalityEntity.PET_TAG)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onTick(LivingEvent.LivingTickEvent event) {
        // Minnoş güneşte yanmaz
        if (event.getEntity() instanceof Zombie z && !z.level().isClientSide
                && z.getPersistentData().getBoolean(MalityEntity.PET_TAG)) {
            if (z.isOnFire()) z.clearFire();
            if (z.getTarget() != null) z.setTarget(null);
        }
        // osuruk etkisi (süper kek)
        if (event.getEntity() instanceof ServerPlayer sp) {
            int t = sp.getPersistentData().getInt("malityFart");
            if (t > 0) {
                sp.getPersistentData().putInt("malityFart", t - 1);
                if (t % 25 == 0 && sp.level() instanceof ServerLevel sl) {
                    sl.playSound(null, sp.blockPosition(), SoundEvents.PUFFER_FISH_BLOW_OUT, SoundSource.PLAYERS, 1.2F, 0.5F);
                    sl.sendParticles(ParticleTypes.SNEEZE, sp.getX(), sp.getY() + 0.6, sp.getZ(), 10, 0.2, 0.1, 0.2, 0.02);
                }
            }
        }
    }
}
